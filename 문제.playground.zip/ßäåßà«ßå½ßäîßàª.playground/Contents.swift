////: Playground - noun: a place where people can play
//
import UIKit
let heros = ["Ironman", "Batman", "BlckWidow", "Tor", "CaptainAmerica", "Spiderman"]
//1. 대문자 소문자 바꾸기(map, for)
//2. 아래 old4배열에서 H이상인것 출력하기
let old4 = [ 1: [ "A", "E", "I", "O", "U", "L", "N", "R", "S", "T" ],
             2: [ "D", "G" ],
             3: [ "B", "C", "M", "P" ],
             4: [ "F", "H", "V", "W", "Y" ],
             5: [ "K"],
             8: [ "J", "X" ],
             10: [ "Q", "Z" ]
]


//3. heros 사전식 배열하기(sort)
//4. 세자리수 짝수 더하기(reduce)
//5. 앞뒤가 대문자인 원소 출력 ( 예: 첫번째 원소에서는 h,n이 출력되어야 합니다.두번째 원소에서는 n이 출력되어야 합니다. 세번째에서는 o,u,g,y가 출력되어야 합니다.)
let Arr = ["ChOihAnNa, hAnSeuNgyeON, JoJuNgHyUN]



